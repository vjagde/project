package incomeTax_161360;

import java.util.ArrayList;
import java.util.Scanner;

public class EmpService {
private static ArrayList<Employees> eArray;
	public void getDetails()
	{
		int e_id;
		String e_name,e_pan;
		double e_annualSal;
		
		EmpValidate v=new EmpValidate();
		
		Scanner scr=new Scanner(System.in);

		System.out.println("Enter Employee ID");
		e_id=scr.nextInt();
		if(v.isValidId(e_id))
		{
			System.out.println("Enter Employee Name");
			e_name=scr.next();
			if(v.isValidName(e_name))
			{
				System.out.println("Enter PAN card number of employee");
				e_pan=scr.next();
				if(v.isValidPan(e_pan))
				{
					System.out.println("Enter annual salary");
					e_annualSal=scr.nextDouble();
					if(v.isValidSal(e_annualSal))
					{
						Employees emp=new Employees(e_id, e_name, e_pan, e_annualSal);
						EmpService.employeeCollection(emp);
					}
					else
					{
						System.out.println("Please enter valid annual salary");
					}
				}
				else
				{
					System.out.println("Please enter valid PAN card number with 10 alphanumeric characters");
				}
			}
			else
			{
				System.out.println("Please enter valid name");
			}
		}
		else
		{
			System.out.println("Please enter valid ID with 3 digits");
		}
		scr.close();
	}
	
	static
	{
		eArray=new ArrayList<Employees>();
		
		Employees emp1=new Employees(101,"Suresh","ATGFH12345",33350.00);
		Employees emp2=new Employees(102,"Mahesh","POKUH28843",150200.00);
		Employees emp3=new Employees(103,"Deepak","ROPET56723",830000.00);
		Employees emp4=new Employees(104,"Pradeep","QWVGT98561",1000350.00);
		Employees emp5=new Employees(105,"Ankita","JUOLP761632",1950000.00);
		
		eArray.add(emp1);
		eArray.add(emp2);
		eArray.add(emp3);
		eArray.add(emp4);
		eArray.add(emp5);
	}
	
	public static void employeeCollection(Employees emp)
	{
		eArray.add(emp);
		
		System.out.println("Your details are successfully added...");
		
		for(Employees temp:eArray)
		{
			System.out.println(temp);
		}
	}

	public void calculate()
	{
		double e_annualSal=0,payable=0,taxRate=0;
		for(Employees e:eArray)
		{
			e_annualSal=e.getE_annualSal();
			if(e_annualSal<=250000)
			{
				taxRate=0;
			}
			else if(e_annualSal>=250001 && e_annualSal<=500000)
			{
				taxRate=0.10;
			}
			else if(e_annualSal>=500001 && e_annualSal<=1000000)
			{
				taxRate=0.20;
			}
			else if(e_annualSal>=1000000)
			{
				taxRate=0.30;
			}
			payable=e_annualSal*taxRate;
			System.out.println("Payable Income Tax amount for "+e.getE_name()+" is Rs."+payable);
		}	
	}
}
