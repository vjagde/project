package incomeTax_161360;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmpValidate {
	
	public boolean isValidId(int e_id)
	{
		String pattern1="\\d{3}";
		String pattern2=String.valueOf(e_id);
		return Pattern.matches(pattern1,pattern2);
	}
	
	public boolean isValidName(String e_name)
	{
		String pattern="[a-zA-Z\\s]+";
		
		return Pattern.matches(pattern, e_name);
	}
	
	public boolean isValidPan(String e_pan)
	{
		String pattern="([a-zA-Z0-9]){5}";
		
		Pattern p=Pattern.compile(pattern);
		Matcher m=p.matcher(e_pan);
		if(m.find())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean isValidSal(double e_annualSal)
	{
		String pattern="^[^-][0-9]+([,.][0-9]{1,2})?";
		Pattern p=Pattern.compile(pattern);
		String sal=String.valueOf(e_annualSal);
		Matcher m=p.matcher(sal);
		if(m.find())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
