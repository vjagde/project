package incomeTax_161360;

public class Employees {
private int e_id;
private String e_name;
private String e_pan;
private double e_annualSal;

@Override
public String toString() {
	return "Employees [e_id=" + e_id + ", e_name=" + e_name + ", e_pan="
			+ e_pan + ", e_annualSal=" + e_annualSal + "]";
}

public Employees(int e_id, String e_name, String e_pan, double e_annualSal) {
	super();
	this.e_id = e_id;
	this.e_name = e_name;
	this.e_pan = e_pan;
	this.e_annualSal = e_annualSal;
}

public int getE_id() {
	return e_id;
}

public void setE_id(int e_id) {
	this.e_id = e_id;
}

public String getE_name() {
	return e_name;
}

public void setE_name(String e_name) {
	this.e_name = e_name;
}

public String getE_pan() {
	return e_pan;
}

public void setE_pan(String e_pan) {
	this.e_pan = e_pan;
}

public double getE_annualSal() {
	return e_annualSal;
}

public void setE_annualSal(double e_annualSal) {
	this.e_annualSal = e_annualSal;
}




}
