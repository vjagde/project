package incomeTax_161360;

import java.util.Scanner;

public class EmpUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean i=true;
		int opt=0;
		
		EmpService s=new EmpService();
		System.out.println("Welcome to Income Tax Calculationg System...");
		Scanner scr=new Scanner(System.in);
		while(i)
		{
			System.out.println("\n1. Add Employee Details");
			System.out.println("2. Compute Income Tax amount and display the details");
			System.out.println("3. Exit");
			System.out.println("Please enter any option from above");
			opt=scr.nextInt();
			switch(opt)
			{
			case 1:
				s.getDetails();
				break;
			
			case 2:
				s.calculate();
				break;
			case 3:
				System.out.println("Closing the application........");
				System.exit(0);
				break;
			default:System.out.println("Wrong Input !!!");
			}
		}
	}

}
