package incomeTax_161360;

import junit.framework.Assert;
import org.junit.BeforeClass;
import org.junit.Test;


public class EmpJunit {

	Employees e;
	EmpService es;
	EmpValidate ev;

	@BeforeClass
	public void myTest() {
		e = new Employees(110, "Vaibhav", "JAGDE09876", 400000.00);
		es = new EmpService();
		ev=new EmpValidate();
	}

	@Test
	public void myTest1() {
		e = new Employees(110, "Vaibhav", "JAGDE09876", 400000.00);
		Assert.assertNotNull(e.getE_name());
		Assert.assertNotNull(e.getE_pan());
		Assert.assertNotNull(e.getE_annualSal());
		Assert.assertNotNull(e.getE_id());
	}
	
	@Test	
	public void myTest2()
	{
		e = new Employees(110, "Vaibhav", "JAGDE09876", 400000.00);
		System.out.println("Running tests");
		Assert.assertNotNull(e.getE_pan());
	}
		
	@Test
	public void myTest3()
	{
		Assert.assertTrue(ev.isValidId(110));
		Assert.assertTrue(ev.isValidName("Vaibhav"));
		Assert.assertTrue(ev.isValidPan("JAGDE09876"));
		Assert.assertTrue(ev.isValidSal(400000.00));
		
	}
}
