package Demo1;

import java.util.Scanner;


public class PgUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		boolean i = true;
		int opt = 0;
		
		
		System.out.println("Welcome to Employee IncomeTax System");
		System.out.println("-------------------------------------");
			
Scanner scr = new Scanner(System.in);
		PgMethod m=new PgMethod();
		while (i) {
			System.out.println("1.Add Customer");
			System.out.println("2.Total no.customer & Total rent");
			System.out.println("3.Remove Customer");
			System.out.println("4.Exit System");
			opt = scr.nextInt();
			switch (opt) {
			case 1: {
					m.getCustomerDetails();
				break;
			}
			case 2: {
					m.TotalCustfees();
				
				break;
			}
			case 3: {
				break;
			}
			case 4:	{
				i = false;
				System.exit(0);
				break;
			}
			
			default: {
				System.out.println("Wrong input\n");
			}
			}
		
	}
	}
}

