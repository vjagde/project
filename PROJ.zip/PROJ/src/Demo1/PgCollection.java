package Demo1;

import java.util.ArrayList;



import Demo1.PgSchema;;

public class PgCollection {
	private static ArrayList<PgSchema> customerList = null;
	static {
		customerList = new ArrayList<PgSchema>();
		PgSchema b1 = new PgSchema("Akshat",75 , "M",7000);
		PgSchema b2 = new PgSchema("Adesh",46 , "M",6000);
		PgSchema b3 = new PgSchema("Ankit",17 , "M",6000);
		PgSchema b4 = new PgSchema("Ayush",8 , "M",6500);
		PgSchema b5 = new PgSchema("Amit",9, "M",7000);

		customerList.add(b1);
		customerList.add(b2);
		customerList.add(b3);
		customerList.add(b4);
		customerList.add(b5);

	}

	/************* Add New Book in ArrayList ************/
	public void addNewCustomerDetails(PgSchema ps) {
		customerList.add(ps);
	}

	public static void setCustomerList(ArrayList<PgSchema> customerList) {
		PgCollection.customerList = customerList;
	}

	public static ArrayList<PgSchema> getCustomerList() {
		return customerList;
	}

	

}
