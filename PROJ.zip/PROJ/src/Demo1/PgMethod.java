package Demo1;

import java.util.Iterator;
import java.util.Scanner;


import Demo1.PgValidator;
import Demo1.PgSchema;
import Demo1.PgCollection;

public class PgMethod {
	
	static PgCollection collectionhelper = null;
	String name;
	int RoomNo;
	String sex;
	double fees;

	public void getCustomerDetails() {
		collectionhelper = new PgCollection();

		PgValidator val = new PgValidator();

		Scanner scr = new Scanner(System.in);

		System.out.println("Enter Name");
		this.name = scr.next();
		if (val.isValidName(name)) {
			System.out.println("Enter Room NO");
			RoomNo = scr.nextInt();
			if (val.isValidRoomNo(RoomNo)) {
				System.out.println("Enter Sex");
				sex = scr.next();
				if (val.isValidSex(sex)) {
					System.out.println("Enter fees");
					fees = scr.nextDouble();
					if (val.isValidfees(fees)) {
						System.out
								.println("Employee Customer are Added Successfully\n");
						PgSchema e = new PgSchema(name, RoomNo, sex,
								fees);
						// System.out.println(e);
						collectionhelper.addNewCustomerDetails(e);
					} else {
						System.out.println("Incorrect fees \n");
					}
				} else {
					System.out.println("Invalid SEx Input\n");

				}
			} else {
				System.out.println("Enter right Room Number \n");
			}
		} else {
			System.out.println("Enter Proper name, not numbers \n");
		}

	}
	
	public void TotalCustfees() {
		collectionhelper = new PgCollection();
		int ts=0;
		for(PgSchema pg:collectionhelper.getCustomerList()) {
		ts=(int) (ts+pg.getFees());
		
		}
		System.out.println(ts);

	}
	public void RemoveCustomer() {
		
		Scanner scr = new Scanner(System.in);
		PgValidator val = new PgValidator();
		
		System.out.println("Enter Room NO");
		RoomNo = scr.nextInt();
		if (val.isValidRoomNo(RoomNo)) {
			
			
		}	
	}
}
