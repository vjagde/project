package Demo1;

public class PgSchema {
	
	private String name;
	private int RoomNo;
	private String Sex;
	private double fees;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRoomNo() {
		return RoomNo;
	}
	public void setRoomNo(int roomNo) {
		RoomNo = roomNo;
	}
	public String getSex() {
		return Sex;
	}
	public void setSex(String sex) {
		Sex = sex;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	public PgSchema(String name, int roomNo, String sex, double fees) {
		super();
		this.name = name;
		RoomNo = roomNo;
		Sex = sex;
		this.fees = fees;
	}
	@Override
	public String toString() {
		return "name= " + name + "\n RoomNo=   " + RoomNo + "\n Sex=   " + Sex + "\n fees=   " + fees + "]";
	}
	
	
	

}
