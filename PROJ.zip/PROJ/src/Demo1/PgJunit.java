package Demo1;

import org.junit.Assert;
import org.junit.Test;

public class PgJunit {
	
	PgValidator pv=new PgValidator();
	
	@Test
	public void test1() {
		Assert.assertTrue(pv.isValidName("Rakesh"));
		Assert.assertTrue(pv.isValidfees(123));
	}
	
	@Test
	public void test2() {
		Assert.assertNotNull(pv.isValidSex("M"));
	} 
	
}
