package Demo1;

import java.util.regex.Pattern;

public class PgValidator {
	
	public boolean isValidName(String s) {

		String Pattern1 = "[a-zA-Z]+\\.?";
		String Pattern2 = String.valueOf(s);
		return Pattern.matches(Pattern1, Pattern2);
	}
		
	public boolean isValidRoomNo(int i) {

		String Pattern1 = "\\d{2}";
		String Pattern2 = String.valueOf(i);
		return Pattern.matches(Pattern1, Pattern2);
	}
		
	public boolean isValidSex(String s) {
		String Pattern1 = "[a-zA-Z]+\\.?";
		String Pattern2 = String.valueOf(s);
		return Pattern.matches(Pattern1, Pattern2);
	}
	
	public boolean isValidfees(double d) {

		String Pattern1 = "[0-9]+([,.][0-9]{1,2})?";
		String Pattern2 = String.valueOf(d);
		return Pattern.matches(Pattern1, Pattern2);
	}
}
